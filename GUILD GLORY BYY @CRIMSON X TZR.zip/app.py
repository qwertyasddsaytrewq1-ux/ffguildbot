#!/usr/bin/env python3
"""Launch the compiled MIDx terminal."""
import asyncio
import io
import os
import sys
os.environ.setdefault('PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION', 'python')


class _BannerPatcher(io.TextIOWrapper):
    """Intercepts stdout writes and replaces banner attribution strings."""

    _REPLACEMENTS = [
        # YT line
        (b'@MIDxCYBER2.0',         b'@CRIMSON MODS'),
        # Developers line - handles replaced individually, same byte length
        (b', @Mid2n',               b'        '),
        (b'@def_rusherexe',         b'@TZR BACK     '),
        (b'@LONECODEX_OFFICIAL',    b'@CRIMSON           '),
        # Free-src notice
        (b'MIDxCYBERZONE team,',   b'CRIMSON MODS  team,'),
    ]

    def __init__(self, raw):
        enc = getattr(sys.__stdout__, 'encoding', None) or 'utf-8'
        super().__init__(raw, encoding=enc, errors='replace', line_buffering=True)

    def write(self, s):
        b = s.encode(self.encoding, errors='replace')
        for old, new in self._REPLACEMENTS:
            b = b.replace(old, new)
        return super().write(b.decode(self.encoding, errors='replace'))


try:
    from midx_guard import verify, ensure_requirements
    verify()
    import google_dns
    google_dns.install()
    ensure_requirements()
    google_dns.install()
    import midx_app
    sys.stdout = _BannerPatcher(sys.stdout.buffer)
    asyncio.run(midx_app.main())
except KeyboardInterrupt:
    print('\n  Stopped.')
except Exception as exc:
    print('  Startup error: ' + str(exc), file=sys.stderr)
    raise SystemExit(1)
finally:
    if isinstance(sys.stdout, _BannerPatcher):
        try:
            sys.stdout = sys.stdout.buffer.raw  # type: ignore[attr-defined]
        except AttributeError:
            sys.stdout = sys.__stdout__
