#!/usr/bin/env python3
"""Run the compiled restart helper."""
from midx_guard import verify
verify()
import keep_compiled
