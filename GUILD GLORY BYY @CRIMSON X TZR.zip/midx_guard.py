"""Native compatibility and checksum checks; not tamper-proof."""
import hashlib
import importlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import sysconfig

ROOT = Path(__file__).resolve().parent
MODULES = {'httpx':'httpx', 'google-play-scraper':'google_play_scraper',
           'pycryptodome':'Crypto', 'protobuf-decoder':'protobuf_decoder',
           'protobuf':'google.protobuf', 'requests':'requests', 'aiohttp':'aiohttp', 'urllib3':'urllib3'}


def _machine(path):
    try:
        with Path(path).open('rb') as stream:
            header = stream.read(20)
    except OSError as exc:
        raise RuntimeError('Cannot read this Python executable. Rebuild on this host.') from exc
    if (len(header) < 20 or header[:4] != b'\x7fELF' or
            header[4] not in (1, 2) or header[5] not in (1, 2)):
        raise RuntimeError('Cannot verify this native Python executable. Rebuild on this host.')
    if (32 if header[4] == 1 else 64) != struct.calcsize('P') * 8:
        raise RuntimeError('Python executable and process bitness do not match.')
    return int.from_bytes(header[18:20], 'little' if header[5] == 1 else 'big')


def _hash(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def verify():
    # No Termux prefix, home directory, VPS provider or installation path lock.
    manifest = json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))
    if not isinstance(manifest, dict) or manifest.get('format') != 'midx-cython-native-v1':
        raise RuntimeError('Unsupported compiled manifest. Rebuild from source here.')
    abi = manifest.get('abi')
    if not isinstance(abi, dict):
        raise RuntimeError('Invalid compiled ABI manifest. Rebuild from source here.')
    if sys.platform != abi.get('platform') or sys.implementation.name != abi.get('implementation'):
        raise RuntimeError('OS or Python implementation differs from the build. Rebuild here.')
    if struct.calcsize('P') * 8 != abi.get('bits'):
        raise RuntimeError('Python bitness differs from the build. Rebuild here.')
    suffix = sysconfig.get_config_var('EXT_SUFFIX')
    if (list(sys.version_info[:2]) != abi.get('python') or
            suffix != abi.get('ext_suffix') or
            sysconfig.get_config_var('SOABI') != abi.get('soabi')):
        raise RuntimeError('Python version or ABI changed. Rebuild with this Python.')
    if _machine(Path(sys.executable).resolve()) != abi.get('machine'):
        raise RuntimeError('Python CPU architecture differs from the build. Rebuild here.')
    modules = manifest.get('modules')
    if not isinstance(modules, dict) or not modules:
        raise RuntimeError('Compiled module manifest is empty or invalid.')
    essential = {'midx_app' + suffix, 'br_worker_compiled' + suffix,
                 'br_engine' + suffix, 'google_dns' + suffix}
    if not essential <= set(modules):
        raise RuntimeError('Compiled module manifest is incomplete.')
    for name, expected in modules.items():
        if (not isinstance(name, str) or Path(name).name != name or '\\' in name or
                not name.endswith(suffix) or not isinstance(expected, str) or
                len(expected) != 64 or any(c not in '0123456789abcdef' for c in expected)):
            raise RuntimeError('Invalid compiled module entry in manifest.')
        path = ROOT / name
        if path.is_symlink() or not path.is_file() or _hash(path) != expected:
            raise RuntimeError('Compiled module missing or modified: ' + name)


def missing_requirements():
    missing = []
    for raw in (ROOT / 'requirements.txt').read_text(encoding='utf-8').splitlines():
        name = raw.strip()
        if not name or name.startswith('#'):
            continue
        if name not in MODULES:
            raise ValueError('Unsupported requirement entry: ' + name)
        try:
            importlib.metadata.version(name)
            spec = importlib.util.find_spec(MODULES[name])
        except (importlib.metadata.PackageNotFoundError, ImportError, ModuleNotFoundError, ValueError):
            spec = None
        if spec is None:
            missing.append(name)
    return missing


def ensure_requirements():
    missing = missing_requirements()
    if not missing:
        return
    print('  Missing requirements: ' + ', '.join(missing), flush=True)
    print('  Installing requirements for this Python interpreter...', flush=True)
    pip_bootstrap = ("import google_dns, runpy; google_dns.install(); "
                     "runpy.run_module('pip', run_name='__main__')")
    subprocess.run([sys.executable, '-c', pip_bootstrap, 'install', '--proxy=',
                    '-r', str(ROOT / 'requirements.txt')], cwd=str(ROOT), check=True)
    importlib.invalidate_caches()
    missing = missing_requirements()
    if missing:
        raise RuntimeError('Requirements still unavailable after installation: ' + ', '.join(missing))
